export declare class AngularPinturaModule {
}
