# Readme

Pintura Image Editor packages need to be transpiled and to do that we need the "next-transpile-modules" package (see https://github.com/vercel/next.js/issues/706, and https://github.com/vercel/next.js/issues/31518).

https://github.com/martpie/next-transpile-modules

`npm i next-transpile-modules --save`

And add or adjust the next.config.js file like this:

```js
// next.config.js
const withTM = require('next-transpile-modules')(['@pqina/pintura', '@pqina/react-pintura']);
module.exports = withTM();
```
