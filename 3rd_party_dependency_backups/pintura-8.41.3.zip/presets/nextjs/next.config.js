const withTM = require('next-transpile-modules')(['@pqina/pintura', '@pqina/react-pintura']);

module.exports = withTM();
