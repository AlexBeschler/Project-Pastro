var __defProp = Object.defineProperty;
var __defProps = Object.defineProperties;
var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
var __getOwnPropSymbols = Object.getOwnPropertySymbols;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __propIsEnum = Object.prototype.propertyIsEnumerable;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __spreadValues = (a, b) => {
  for (var prop in b || (b = {}))
    if (__hasOwnProp.call(b, prop))
      __defNormalProp(a, prop, b[prop]);
  if (__getOwnPropSymbols)
    for (var prop of __getOwnPropSymbols(b)) {
      if (__propIsEnum.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    }
  return a;
};
var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));
import { c as create_ssr_component, o as onDestroy, a as add_attribute, b as createEventDispatcher, v as validate_component } from "../../chunks/index-441c5191.js";
import * as FilePond from "filepond";
import { registerPlugin } from "filepond";
import FilePondPluginFilePoster from "filepond-plugin-file-poster";
import { setPlugins, plugin_crop, plugin_finetune, plugin_filter, plugin_annotate, createDefaultImageReader, createDefaultImageWriter, createDefaultShapePreprocessor, plugin_finetune_defaults, plugin_filter_defaults, markup_editor_defaults, locale_en_gb, plugin_crop_locale_en_gb, plugin_finetune_locale_en_gb, plugin_filter_locale_en_gb, plugin_annotate_locale_en_gb, markup_editor_locale_en_gb, legacyDataToImageState, openEditor, processImage, createDefaultImageOrienter } from "@pqina/pintura";
const Component = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  const registerPlugin2 = FilePond.registerPlugin;
  const isSupported = FilePond.supported();
  let { class: klass = void 0 } = $$props;
  let { id = void 0 } = $$props;
  let { name = void 0 } = $$props;
  let { allowMultiple = void 0 } = $$props;
  let { required = void 0 } = $$props;
  let { captureMethod = void 0 } = $$props;
  let { acceptedFileTypes = void 0 } = $$props;
  const noop2 = () => {
  };
  let { addFile = noop2 } = $$props;
  let { addFiles = noop2 } = $$props;
  let { browse = noop2 } = $$props;
  let { fireSync = noop2 } = $$props;
  let { getFile = noop2 } = $$props;
  let { getFiles = noop2 } = $$props;
  let { moveFile = noop2 } = $$props;
  let { prepareFile = noop2 } = $$props;
  let { prepareFiles = noop2 } = $$props;
  let { processFile = noop2 } = $$props;
  let { processFiles = noop2 } = $$props;
  let { removeFile = noop2 } = $$props;
  let { removeFiles = noop2 } = $$props;
  let { sort = noop2 } = $$props;
  onDestroy(() => {
    return;
  });
  if ($$props.registerPlugin === void 0 && $$bindings.registerPlugin && registerPlugin2 !== void 0)
    $$bindings.registerPlugin(registerPlugin2);
  if ($$props.isSupported === void 0 && $$bindings.isSupported && isSupported !== void 0)
    $$bindings.isSupported(isSupported);
  if ($$props.class === void 0 && $$bindings.class && klass !== void 0)
    $$bindings.class(klass);
  if ($$props.id === void 0 && $$bindings.id && id !== void 0)
    $$bindings.id(id);
  if ($$props.name === void 0 && $$bindings.name && name !== void 0)
    $$bindings.name(name);
  if ($$props.allowMultiple === void 0 && $$bindings.allowMultiple && allowMultiple !== void 0)
    $$bindings.allowMultiple(allowMultiple);
  if ($$props.required === void 0 && $$bindings.required && required !== void 0)
    $$bindings.required(required);
  if ($$props.captureMethod === void 0 && $$bindings.captureMethod && captureMethod !== void 0)
    $$bindings.captureMethod(captureMethod);
  if ($$props.acceptedFileTypes === void 0 && $$bindings.acceptedFileTypes && acceptedFileTypes !== void 0)
    $$bindings.acceptedFileTypes(acceptedFileTypes);
  if ($$props.addFile === void 0 && $$bindings.addFile && addFile !== void 0)
    $$bindings.addFile(addFile);
  if ($$props.addFiles === void 0 && $$bindings.addFiles && addFiles !== void 0)
    $$bindings.addFiles(addFiles);
  if ($$props.browse === void 0 && $$bindings.browse && browse !== void 0)
    $$bindings.browse(browse);
  if ($$props.fireSync === void 0 && $$bindings.fireSync && fireSync !== void 0)
    $$bindings.fireSync(fireSync);
  if ($$props.getFile === void 0 && $$bindings.getFile && getFile !== void 0)
    $$bindings.getFile(getFile);
  if ($$props.getFiles === void 0 && $$bindings.getFiles && getFiles !== void 0)
    $$bindings.getFiles(getFiles);
  if ($$props.moveFile === void 0 && $$bindings.moveFile && moveFile !== void 0)
    $$bindings.moveFile(moveFile);
  if ($$props.prepareFile === void 0 && $$bindings.prepareFile && prepareFile !== void 0)
    $$bindings.prepareFile(prepareFile);
  if ($$props.prepareFiles === void 0 && $$bindings.prepareFiles && prepareFiles !== void 0)
    $$bindings.prepareFiles(prepareFiles);
  if ($$props.processFile === void 0 && $$bindings.processFile && processFile !== void 0)
    $$bindings.processFile(processFile);
  if ($$props.processFiles === void 0 && $$bindings.processFiles && processFiles !== void 0)
    $$bindings.processFiles(processFiles);
  if ($$props.removeFile === void 0 && $$bindings.removeFile && removeFile !== void 0)
    $$bindings.removeFile(removeFile);
  if ($$props.removeFiles === void 0 && $$bindings.removeFiles && removeFiles !== void 0)
    $$bindings.removeFiles(removeFiles);
  if ($$props.sort === void 0 && $$bindings.sort && sort !== void 0)
    $$bindings.sort(sort);
  return `



<div class="${"filepond--wrapper"}"><input type="${"file"}"${add_attribute("id", id, 0)}${add_attribute("name", name, 0)}${add_attribute("class", klass, 0)}${add_attribute("accept", acceptedFileTypes, 0)} ${allowMultiple ? "multiple" : ""} ${required ? "required" : ""}${add_attribute("capture", captureMethod, 0)}></div>`;
});
/*!
 * Pintura Image Editor 8.30.0
 * (c) 2018-2022 PQINA Inc. - All Rights Reserved
 * License: https://pqina.nl/pintura/license/
 */
var isFile = (v) => v instanceof File;
var isImage = (file) => /^image/.test(file.type);
var isString = (v) => typeof v === "string";
var h = (name, attributes, children = []) => {
  const el = document.createElement(name);
  const descriptors = Object.getOwnPropertyDescriptors(el.__proto__);
  for (const key in attributes) {
    if (key === "style") {
      el.style.cssText = attributes[key];
    } else if (descriptors[key] && descriptors[key].set || /textContent|innerHTML/.test(key) || typeof attributes[key] === "function") {
      el[key] = attributes[key];
    } else {
      el.setAttribute(key, attributes[key]);
    }
  }
  children.forEach((child) => el.appendChild(child));
  return el;
};
let result$4 = null;
var isBrowser = () => {
  if (result$4 === null)
    result$4 = typeof window !== "undefined" && typeof window.document !== "undefined";
  return result$4;
};
const supportsReplaceChildren = isBrowser() && !!Node.prototype.replaceChildren;
const fn = supportsReplaceChildren ? (parent, newChildren) => parent.replaceChildren(newChildren) : (parent, newChildren) => {
  while (parent.lastChild) {
    parent.removeChild(parent.lastChild);
  }
  if (newChildren !== void 0) {
    parent.append(newChildren);
  }
};
const container = isBrowser() && h("div", {
  class: "PinturaMeasure",
  style: "pointer-events:none;left:0;top:0;width:0;height:0;contain:strict;overflow:hidden;position:absolute;"
});
let timeoutId;
var appendForMeasuring = (element) => {
  fn(container, element);
  if (!container.parentNode)
    document.body.append(container);
  clearTimeout(timeoutId);
  timeoutId = setTimeout(() => {
    container.remove();
  }, 500);
  return element;
};
let result$3 = null;
var isSafari = () => {
  if (result$3 === null)
    result$3 = isBrowser() && /^((?!chrome|android).)*(safari|iphone|ipad)/i.test(navigator.userAgent);
  return result$3;
};
var getImageElementSize = (imageElement) => new Promise((resolve, reject) => {
  let shouldAutoRemove = false;
  if (!imageElement.parentNode && isSafari()) {
    shouldAutoRemove = true;
    imageElement.style.cssText = `position:absolute;visibility:hidden;pointer-events:none;left:0;top:0;width:0;height:0;`;
    appendForMeasuring(imageElement);
  }
  const measure = () => {
    const width = imageElement.naturalWidth;
    const height = imageElement.naturalHeight;
    const hasSize = width && height;
    if (!hasSize)
      return;
    if (shouldAutoRemove)
      imageElement.remove();
    clearInterval(intervalId);
    resolve({ width, height });
  };
  imageElement.onerror = (err) => {
    clearInterval(intervalId);
    reject(err);
  };
  const intervalId = setInterval(measure, 1);
  measure();
});
var getImageSize = async (image) => {
  let imageElement = image;
  if (!imageElement.src) {
    imageElement = new Image();
    imageElement.src = isString(image) ? image : URL.createObjectURL(image);
  }
  let size;
  try {
    size = await getImageElementSize(imageElement);
  } finally {
    isFile(image) && URL.revokeObjectURL(imageElement.src);
  }
  return size;
};
var isBlob = (v) => v instanceof Blob && !(v instanceof File);
var noop = (...args) => {
};
var releaseCanvas = (canvas) => {
  canvas.width = 1;
  canvas.height = 1;
  const ctx = canvas.getContext("2d");
  ctx && ctx.clearRect(0, 0, 1, 1);
};
let result$2 = null;
var supportsWebGL2 = () => {
  if (result$2 === null) {
    if ("WebGL2RenderingContext" in window) {
      let canvas;
      try {
        canvas = h("canvas");
        result$2 = !!canvas.getContext("webgl2");
      } catch (err) {
        result$2 = false;
      }
      canvas && releaseCanvas(canvas);
      canvas = void 0;
    } else {
      result$2 = false;
    }
  }
  return result$2;
};
var getWebGLContext = (canvas, attrs) => {
  if (supportsWebGL2())
    return canvas.getContext("webgl2", attrs);
  return canvas.getContext("webgl", attrs) || canvas.getContext("experimental-webgl", attrs);
};
let result$1 = null;
var supportsWebGL = () => {
  if (result$1 === null) {
    let canvas = h("canvas");
    result$1 = !!getWebGLContext(canvas);
    releaseCanvas(canvas);
    canvas = void 0;
  }
  return result$1;
};
const isOperaMini = () => Object.prototype.toString.call(window["operamini"]) === "[object OperaMini]";
const hasPromises = () => "Promise" in window;
const hasCreateObjectURL = () => "URL" in window && "createObjectURL" in window.URL;
const hasVisibility = () => "visibilityState" in document;
const hasTiming = () => "performance" in window;
const hasFileConstructor = () => "File" in window;
let result = null;
var isModernBrowser = () => {
  if (result === null)
    result = isBrowser() && !isOperaMini() && hasVisibility() && hasPromises() && hasFileConstructor() && hasCreateObjectURL() && hasTiming();
  return result;
};
const plugin = (_) => {
  const { addFilter, utils, views } = _;
  const { Type, createRoute } = utils;
  const { fileActionButton } = views;
  const createQueue = ({ parallel = 1, autoShift = true }) => {
    const queue = [];
    let jobs = 0;
    const next = () => {
      if (!queue.length)
        return api.oncomplete();
      jobs++;
      const job = queue.shift();
      job(() => {
        jobs--;
        if (jobs < parallel)
          runJobs();
      });
    };
    const runJobs = () => {
      for (let i = 0; i < parallel - jobs; i++) {
        next();
      }
    };
    const api = {
      queue: (cb) => {
        queue.push(cb);
        autoShift && runJobs();
      },
      runJobs,
      oncomplete: () => {
      }
    };
    return api;
  };
  const renderQueue = createQueue({ parallel: 1 });
  const getEditorSafe = (editor) => editor === null ? {} : editor;
  addFilter("SHOULD_REMOVE_ON_REVERT", (shouldRemove, { item, query }) => new Promise((resolve) => {
    const { file } = item;
    const canEdit = query("GET_ALLOW_IMAGE_EDITOR") && query("GET_IMAGE_EDITOR_ALLOW_EDIT") && query("GET_IMAGE_EDITOR_SUPPORT_EDIT") && query("GET_IMAGE_EDITOR_SUPPORT_IMAGE")(file);
    resolve(!canEdit);
  }));
  addFilter("DID_LOAD_ITEM", (item, { query, dispatch }) => new Promise((resolve, reject) => {
    if (item.origin > 1) {
      resolve(item);
      return;
    }
    const { file } = item;
    if (!query("GET_ALLOW_IMAGE_EDITOR") || !query("GET_IMAGE_EDITOR_INSTANT_EDIT"))
      return resolve(item);
    if (!query("GET_IMAGE_EDITOR_SUPPORT_IMAGE")(file))
      return resolve(item);
    const requestEdit = () => {
      if (!editRequestQueue.length)
        return;
      const { item: item2, resolve: resolve2, reject: reject2 } = editRequestQueue[0];
      dispatch("EDIT_ITEM", {
        id: item2.id,
        handleEditorResponse: createEditorResponseHandler(item2, resolve2, reject2)
      });
    };
    const createEditorResponseHandler = (item2, resolve2, reject2) => (userDidConfirm) => {
      editRequestQueue.shift();
      if (userDidConfirm) {
        resolve2(item2);
      } else {
        reject2(item2);
      }
      dispatch("KICK");
      requestEdit();
    };
    queueEditRequest({ item, resolve, reject });
    if (editRequestQueue.length === 1) {
      requestEdit();
    }
  }));
  addFilter("DID_CREATE_ITEM", (item, { query, dispatch }) => {
    item.extend("edit", () => {
      dispatch("EDIT_ITEM", { id: item.id });
    });
  });
  const editRequestQueue = [];
  const queueEditRequest = (editRequest) => {
    editRequestQueue.push(editRequest);
    return editRequest;
  };
  const couldTransformFile = (query) => {
    const { imageProcessor, imageReader, imageWriter } = getEditorSafe(query("GET_IMAGE_EDITOR"));
    return query("GET_IMAGE_EDITOR_WRITE_IMAGE") && query("GET_IMAGE_EDITOR_SUPPORT_WRITE_IMAGE") && imageProcessor && imageReader && imageWriter;
  };
  const getPosterTargetSize = (query, targetSize) => {
    const posterHeight = query("GET_FILE_POSTER_HEIGHT");
    const maxPosterHeight = query("GET_FILE_POSTER_MAX_HEIGHT");
    if (posterHeight) {
      targetSize.width = posterHeight * 2;
      targetSize.height = posterHeight * 2;
    } else if (maxPosterHeight) {
      targetSize.width = maxPosterHeight * 2;
      targetSize.height = maxPosterHeight * 2;
    }
    return targetSize;
  };
  const createImagePoster = (query, item, done = () => {
  }) => {
    if (!item)
      return;
    const { imageProcessor, imageReader, imageWriter, editorOptions, imageState: imageBaseState } = getEditorSafe(query("GET_IMAGE_EDITOR"));
    if (!imageProcessor)
      return;
    const [createImageReader, imageReaderOptions] = imageReader;
    const [createImageWriter = noop, imageWriterOptions] = imageWriter;
    const file = item.file;
    const imageState = item.getMetadata("imageState");
    const targetSize = getPosterTargetSize(query, {
      width: 512,
      height: 512
    });
    const options = __spreadProps(__spreadValues({}, editorOptions), {
      imageReader: createImageReader(imageReaderOptions),
      imageWriter: createImageWriter(__spreadProps(__spreadValues({}, imageWriterOptions || {}), {
        canvasMemoryLimit: targetSize.width * targetSize.height * 2
      })),
      imageState: __spreadValues(__spreadValues({}, imageBaseState), imageState)
    });
    renderQueue.queue((next) => {
      imageProcessor(file, options).then(({ dest }) => {
        item.setMetadata("poster", URL.createObjectURL(dest), true);
        next();
        done();
      });
    });
  };
  addFilter("CREATE_VIEW", (viewAPI) => {
    const { is, view, query } = viewAPI;
    if (!query("GET_ALLOW_IMAGE_EDITOR"))
      return;
    if (!query("GET_IMAGE_EDITOR_SUPPORT_WRITE_IMAGE"))
      return;
    const supportsFilePoster = query("GET_ALLOW_FILE_POSTER");
    const shouldExtendView = is("file-info") && !supportsFilePoster || is("file") && supportsFilePoster;
    if (!shouldExtendView)
      return;
    const { createEditor, imageReader, imageWriter, editorOptions, legacyDataToImageState: legacyDataToImageState2, imageState: imageBaseState } = getEditorSafe(query("GET_IMAGE_EDITOR"));
    if (!imageReader || !imageWriter || !editorOptions || !editorOptions.locale)
      return;
    delete editorOptions.imageReader;
    delete editorOptions.imageWriter;
    const [createImageReader, imageReaderOptions] = imageReader;
    const getItemByProps = (props) => {
      const { id } = props;
      const item = query("GET_ITEM", id);
      return item;
    };
    const hasPoster = (props) => {
      if (!query("GET_ALLOW_FILE_POSTER"))
        return false;
      const item = getItemByProps(props);
      if (!item)
        return;
      if (!query("GET_FILE_POSTER_FILTER_ITEM")(item))
        return false;
      const poster = item.getMetadata("poster");
      return !!poster;
    };
    const openImageEditor = ({ root, props, action }) => {
      const { handleEditorResponse } = action;
      const item = getItemByProps(props);
      const file = item.file;
      const editor = createEditor(__spreadProps(__spreadValues({}, editorOptions), {
        imageReader: createImageReader(imageReaderOptions),
        src: file
      }));
      editor.on("load", ({ size }) => {
        let imageState = item.getMetadata("imageState");
        imageState = legacyDataToImageState2 ? legacyDataToImageState2(editor, size, imageState) : imageState;
        editor.imageState = __spreadValues(__spreadValues({}, imageBaseState), imageState);
      });
      editor.on("process", ({ imageState }) => {
        item.setMetadata("imageState", imageState);
        if (!handleEditorResponse)
          return;
        handleEditorResponse(true);
      });
      editor.on("close", () => {
        if (!handleEditorResponse)
          return;
        handleEditorResponse(false);
      });
    };
    const didLoadItem = ({ root, props }) => {
      const { id } = props;
      const item = query("GET_ITEM", id);
      if (!item)
        return;
      const file = item.file;
      if (!query("GET_IMAGE_EDITOR_SUPPORT_IMAGE")(file))
        return;
      if (query("GET_ALLOW_FILE_POSTER") && !item.getMetadata("poster")) {
        root.dispatch("REQUEST_CREATE_IMAGE_POSTER", { id });
      }
      if (!query("GET_IMAGE_EDITOR_ALLOW_EDIT") || !query("GET_IMAGE_EDITOR_SUPPORT_EDIT"))
        return;
      updateEditButton(root, props);
    };
    const updateEditButton = (root, props) => {
      if (!root.ref.handleEdit) {
        root.ref.handleEdit = (e) => {
          e.stopPropagation();
          root.dispatch("EDIT_ITEM", { id: props.id });
        };
      }
      if (hasPoster(props)) {
        if (root.ref.editButton && root.ref.editButton.parentNode) {
          root.ref.editButton.parentNode.removeChild(root.ref.editButton);
        }
        const buttonView = view.createChildView(fileActionButton, {
          label: "edit",
          icon: query("GET_IMAGE_EDITOR_ICON_EDIT"),
          opacity: 0
        });
        buttonView.element.classList.add("filepond--action-edit-item");
        buttonView.element.dataset.align = query("GET_STYLE_IMAGE_EDITOR_BUTTON_EDIT_ITEM_POSITION");
        buttonView.on("click", root.ref.handleEdit);
        root.ref.buttonEditItem = view.appendChildView(buttonView);
      } else {
        if (root.ref.buttonEditItem) {
          root.removeChildView(root.ref.buttonEditItem);
        }
        const filenameElement = view.element.querySelector(".filepond--file-info-main");
        const editButton = document.createElement("button");
        editButton.className = "filepond--action-edit-item-alt";
        editButton.innerHTML = query("GET_IMAGE_EDITOR_ICON_EDIT") + "<span>edit</span>";
        editButton.addEventListener("click", root.ref.handleEdit);
        filenameElement.appendChild(editButton);
        root.ref.editButton = editButton;
      }
    };
    const didUpdateItemMetadata = ({ root, props, action }) => {
      if (/imageState/.test(action.change.key) && query("GET_ALLOW_FILE_POSTER"))
        return root.dispatch("REQUEST_CREATE_IMAGE_POSTER", { id: props.id });
      if (!/poster/.test(action.change.key))
        return;
      if (!query("GET_IMAGE_EDITOR_ALLOW_EDIT") || !query("GET_IMAGE_EDITOR_SUPPORT_EDIT"))
        return;
      updateEditButton(root, props);
    };
    view.registerDestroyer(({ root }) => {
      if (root.ref.buttonEditItem) {
        root.ref.buttonEditItem.off("click", root.ref.handleEdit);
      }
      if (root.ref.editButton) {
        root.ref.editButton.removeEventListener("click", root.ref.handleEdit);
      }
    });
    const routes = {
      EDIT_ITEM: openImageEditor,
      DID_LOAD_ITEM: didLoadItem,
      DID_UPDATE_ITEM_METADATA: didUpdateItemMetadata,
      DID_REMOVE_ITEM: ({ props }) => {
        const { id } = props;
        const item = query("GET_ITEM", id);
        if (!item)
          return;
        const poster = item.getMetadata("poster");
        poster && URL.revokeObjectURL(poster);
      },
      REQUEST_CREATE_IMAGE_POSTER: ({ root, props }) => createImagePoster(root.query, getItemByProps(props)),
      DID_FILE_POSTER_LOAD: void 0
    };
    if (supportsFilePoster) {
      const didPosterUpdate = ({ root }) => {
        if (!root.ref.buttonEditItem)
          return;
        root.ref.buttonEditItem.opacity = 1;
      };
      routes.DID_FILE_POSTER_LOAD = didPosterUpdate;
    }
    view.registerWriter(createRoute(routes));
  });
  addFilter("SHOULD_PREPARE_OUTPUT", (shouldPrepareOutput, { query, change, item }) => new Promise((resolve) => {
    if (!query("GET_IMAGE_EDITOR_SUPPORT_IMAGE")(item.file))
      return resolve(false);
    if (change && !/imageState/.test(change.key))
      return resolve(false);
    resolve(!query("IS_ASYNC"));
  }));
  const shouldTransformFile = (query, file, item) => new Promise((resolve) => {
    if (!couldTransformFile(query) || item.archived || !isFile(file) && !isBlob(file) || !query("GET_IMAGE_EDITOR_SUPPORT_IMAGE")(file)) {
      return resolve(false);
    }
    getImageSize(file).then(() => {
      const fn2 = query("GET_IMAGE_TRANSFORM_IMAGE_FILTER");
      if (fn2) {
        const filterResult = fn2(file);
        if (typeof filterResult === "boolean") {
          return resolve(filterResult);
        }
        if (typeof filterResult.then === "function") {
          return filterResult.then(resolve);
        }
      }
      resolve(true);
    }).catch(() => {
      resolve(false);
    });
  });
  addFilter("PREPARE_OUTPUT", (file, { query, item }) => {
    const writeOutputImage = (file2) => new Promise((resolve, reject) => {
      const prepare = () => {
        renderQueue.queue((next) => {
          const imageState = item.getMetadata("imageState");
          const { imageProcessor, imageReader, imageWriter, editorOptions, imageState: imageBaseState } = getEditorSafe(query("GET_IMAGE_EDITOR"));
          if (!imageProcessor || !imageReader || !imageWriter || !editorOptions)
            return;
          const [createImageReader, imageReaderOptions] = imageReader;
          const [createImageWriter = noop, imageWriterOptions] = imageWriter;
          imageProcessor(file2, __spreadProps(__spreadValues({}, editorOptions), {
            imageReader: createImageReader(imageReaderOptions),
            imageWriter: createImageWriter(imageWriterOptions),
            imageState: __spreadValues(__spreadValues({}, imageBaseState), imageState)
          })).then(resolve).catch(reject).finally(next);
        });
      };
      if (query("GET_ALLOW_FILE_POSTER") && !item.getMetadata("poster")) {
        createImagePoster(query, item, prepare);
      } else {
        prepare();
      }
    });
    return new Promise((resolve) => {
      shouldTransformFile(query, file, item).then((shouldWrite) => {
        if (!shouldWrite)
          return resolve(file);
        writeOutputImage(file).then((res) => {
          const afterFn = query("GET_IMAGE_EDITOR_AFTER_WRITE_IMAGE");
          if (afterFn)
            return Promise.resolve(afterFn(res)).then(resolve);
          resolve(res.dest);
        });
      });
    });
  });
  return {
    options: {
      allowImageEditor: [true, Type.BOOLEAN],
      imageEditorInstantEdit: [false, Type.BOOLEAN],
      imageEditorAllowEdit: [true, Type.BOOLEAN],
      imageEditorSupportEdit: [
        isBrowser() && isModernBrowser() && supportsWebGL(),
        Type.BOOLEAN
      ],
      imageEditorSupportImage: [isImage, Type.FUNCTION],
      imageEditorSupportWriteImage: [isModernBrowser(), Type.BOOLEAN],
      imageEditorWriteImage: [true, Type.BOOLEAN],
      imageEditorAfterWriteImage: [void 0, Type.FUNCTION],
      imageEditor: [null, Type.OBJECT],
      imageEditorIconEdit: [
        '<svg width="26" height="26" viewBox="0 0 26 26" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false"><path d="M8.5 17h1.586l7-7L15.5 8.414l-7 7V17zm-1.707-2.707l8-8a1 1 0 0 1 1.414 0l3 3a1 1 0 0 1 0 1.414l-8 8A1 1 0 0 1 10.5 19h-3a1 1 0 0 1-1-1v-3a1 1 0 0 1 .293-.707z" fill="currentColor" fill-rule="nonzero"/></svg>',
        Type.STRING
      ],
      styleImageEditorButtonEditItemPosition: ["bottom center", Type.STRING]
    }
  };
};
if (isBrowser())
  document.dispatchEvent(new CustomEvent("FilePond:pluginloaded", { detail: plugin }));
var filepond_min = "";
var filepondPluginFilePoster_min = "";
const PinturaEditor = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  createEventDispatcher();
  let { editor = void 0 } = $$props;
  let element;
  let unsubs = [];
  onDestroy(() => {
    if (!editor)
      return;
    editor.destroy();
    unsubs.forEach((unsub) => unsub());
    unsubs = [];
    editor = void 0;
  });
  if ($$props.editor === void 0 && $$bindings.editor && editor !== void 0)
    $$bindings.editor(editor);
  return `



<div class="${"PinturaRootWrapper"}"${add_attribute("this", element, 0)}></div>`;
});
var pintura = "";
var index_svelte_svelte_type_style_lang = "";
const css = {
  code: "img.svelte-ojzt9c{max-width:100%}",
  map: null
};
const Routes = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  registerPlugin(FilePondPluginFilePoster, plugin);
  setPlugins(plugin_crop, plugin_finetune, plugin_filter, plugin_annotate);
  const editorDefaults = __spreadProps(__spreadValues(__spreadValues(__spreadValues({
    imageReader: createDefaultImageReader(),
    imageWriter: createDefaultImageWriter(),
    shapePreprocessor: createDefaultShapePreprocessor()
  }, plugin_finetune_defaults), plugin_filter_defaults), markup_editor_defaults), {
    locale: __spreadValues(__spreadValues(__spreadValues(__spreadValues(__spreadValues(__spreadValues({}, locale_en_gb), plugin_crop_locale_en_gb), plugin_finetune_locale_en_gb), plugin_filter_locale_en_gb), plugin_annotate_locale_en_gb), markup_editor_locale_en_gb)
  });
  $$result.css.add(css);
  return `<main><h1>Pintura Image Editor</h1>

	<h2>Inline</h2>

	<div style="${"height:70vh"}">${validate_component(PinturaEditor, "PinturaEditor").$$render($$result, Object.assign(editorDefaults, { src: "image.jpeg" }), {}, {})}</div>

	${``}

	<h2>Modal</h2>

	<p><button>Open editor</button></p>

	${``}

	${``}

	<h2>Overlay</h2>

	<p>${`<button>Edit image</button>`}</p>

	${`<p><img width="${"512"}" height="${"256"}"${add_attribute("src", "image.jpeg", 0)} alt="${""}" class="${"svelte-ojzt9c"}"></p>`}

	<h2>FilePond</h2>

	<div style="${"max-width: 20em; padding-bottom: 2em;"}">${validate_component(Component, "FilePond").$$render($$result, {
    server: "/api",
    allowMultiple: true,
    imageEditor: {
      legacyDataToImageState,
      createEditor: openEditor,
      imageReader: [createDefaultImageReader, {}],
      imageWriter: [createDefaultImageWriter, {}],
      imageProcessor: processImage,
      editorOptions: __spreadProps(__spreadValues(__spreadValues(__spreadValues({
        imageOrienter: createDefaultImageOrienter()
      }, plugin_finetune_defaults), plugin_filter_defaults), markup_editor_defaults), {
        locale: __spreadValues(__spreadValues(__spreadValues(__spreadValues(__spreadValues(__spreadValues({}, locale_en_gb), plugin_crop_locale_en_gb), plugin_finetune_locale_en_gb), plugin_filter_locale_en_gb), plugin_annotate_locale_en_gb), markup_editor_locale_en_gb)
      })
    }
  }, {}, {})}</div>
</main>`;
});
export { Routes as default };
