import { c as create_ssr_component } from "../../chunks/index-441c5191.js";
const Layout = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  return `${slots.default ? slots.default({}) : ``}`;
});
export { Layout as default };
