import * as module from '../entries/fallbacks/error.svelte.js';

export { module };
export const entry = 'error.svelte-d7585bcc.js';
export const js = ["error.svelte-d7585bcc.js","chunks/index-219f6fe4.js"];
export const css = [];
