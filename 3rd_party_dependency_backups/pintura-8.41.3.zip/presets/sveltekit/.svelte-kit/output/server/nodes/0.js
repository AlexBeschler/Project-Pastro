import * as module from '../entries/fallbacks/layout.svelte.js';

export { module };
export const entry = 'layout.svelte-b442a8a2.js';
export const js = ["layout.svelte-b442a8a2.js","chunks/index-219f6fe4.js"];
export const css = [];
