import * as module from '../entries/pages/index.svelte.js';

export { module };
export const entry = 'pages/index.svelte-1155c677.js';
export const js = ["pages/index.svelte-1155c677.js","chunks/index-219f6fe4.js"];
export const css = ["assets/pages/index.svelte-3d3460d2.css"];
